<template>
  <div>
    <Map/>
  </div>
</template>

<script>
// components
import Map from '@/components/lines/Map.vue'

export default {
 name: 'LinesView',
 components: { Map },
}
</script>

<style>

</style>