// api/index.js

export default {
  URL: '',
  ROUTES: {},
}